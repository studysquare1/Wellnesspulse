export type MoodLevel = 'mania' | 'hypomania' | 'euthymia' | 'depression' | 'major-depression';

export interface MoodPoint {
  time: string;
  mood: MoodLevel;
  emoji: string;
  x: number;
  y: number;
}

export const getMoodFromY = (yPercent: number): MoodLevel => {
  if (yPercent < 20) return 'mania';
  if (yPercent < 40) return 'hypomania';
  if (yPercent < 60) return 'euthymia';
  if (yPercent < 80) return 'depression';
  return 'major-depression';
};

export const getTimeFromX = (xPercent: number): string => {
  // Start from 5 AM and span 24 hours
  const hour = Math.floor(((xPercent / 100) * 24) + 5) % 24;
  return `${hour.toString().padStart(2, '0')}:00`;
};

export const getTimePeriods = () => [
  { label: "05:00-08:00", period: "Early Morning", emoji: "🌅", bgClass: "from-blue-100 to-purple-100" },
  { label: "08:00-11:00", period: "Morning", emoji: "☀️", bgClass: "from-yellow-100 to-orange-100" },
  { label: "11:00-14:00", period: "Late Morning", emoji: "🌱", bgClass: "from-green-100 to-blue-100" },
  { label: "14:00-17:00", period: "Afternoon", emoji: "🌞", bgClass: "from-orange-100 to-red-100" },
  { label: "17:00-20:00", period: "Evening", emoji: "🌇", bgClass: "from-pink-100 to-purple-100" },
  { label: "20:00-23:00", period: "Dusk", emoji: "🌆", bgClass: "from-purple-100 to-indigo-100" },
  { label: "23:00-02:00", period: "Night", emoji: "🌃", bgClass: "from-indigo-100 to-purple-100" },
  { label: "02:00-05:00", period: "Deep Night", emoji: "🌙", bgClass: "from-purple-100 to-pink-100" },
];

export const formatDate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

export const getCurrentWeek = (): string => {
  const today = new Date();
  const startOfWeek = new Date(today);
  startOfWeek.setDate(today.getDate() - today.getDay());
  return formatDate(startOfWeek);
};
