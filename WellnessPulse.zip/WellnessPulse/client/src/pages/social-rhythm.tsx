import { useState, useEffect } from "react";
import React from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import EmojiSelector from "@/components/emoji-selector";
import { apiRequest } from "@/lib/queryClient";
import { getCurrentWeek } from "@/lib/mood-utils";
import type { RhythmEntry, RoutineEntry } from "@shared/schema";
import childWithBuds from "@assets/e6e8bddf74c705bdb53052610328eead_1750482394286.jpg";

const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

export default function SocialRhythm() {
  const [weekOf, setWeekOf] = useState(getCurrentWeek());
  const [routines, setRoutines] = useState<RoutineEntry[]>([
    {
      routine: "Get out of bed and stand up",
      idealTime: "",
      days: daysOfWeek.reduce((acc, day) => ({ ...acc, [day]: { actualTime: "", people: "😊" } }), {})
    },
    {
      routine: "Evening wind-down",
      idealTime: "",
      days: daysOfWeek.reduce((acc, day) => ({ ...acc, [day]: { actualTime: "", people: "🌙" } }), {})
    }
  ]);
  const [selectedCell, setSelectedCell] = useState<{ routineIndex: number; day: string } | null>(null);
  const [showEmojiSelector, setShowEmojiSelector] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: rhythmData } = useQuery<RhythmEntry>({
    queryKey: [`/api/rhythm/${weekOf}`],
    enabled: !!weekOf,
  });

  const saveMutation = useMutation({
    mutationFn: async (data: { weekOf: string; routines: RoutineEntry[] }) => {
      const response = await apiRequest("POST", "/api/rhythm", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/rhythm/${weekOf}`] });
      toast({
        title: "Saved!",
        description: "Your social rhythm chart has been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save your social rhythm chart.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (rhythmData?.routines) {
      setRoutines(rhythmData.routines);
    }
  }, [rhythmData]);

  const handleRoutineChange = (index: number, field: keyof RoutineEntry, value: any) => {
    const newRoutines = [...routines];
    if (field === 'days') {
      newRoutines[index] = { ...newRoutines[index], days: { ...newRoutines[index].days, ...value } };
    } else {
      newRoutines[index] = { ...newRoutines[index], [field]: value };
    }
    setRoutines(newRoutines);
  };

  const handleTimeChange = (routineIndex: number, day: string, time: string) => {
    const newDays = { ...routines[routineIndex].days };
    newDays[day] = { ...newDays[day], actualTime: time };
    handleRoutineChange(routineIndex, 'days', newDays);
  };

  const handleEmojiClick = (routineIndex: number, day: string) => {
    setSelectedCell({ routineIndex, day });
    setShowEmojiSelector(true);
  };

  const handleEmojiSelect = (emoji: string) => {
    if (selectedCell) {
      const { routineIndex, day } = selectedCell;
      const newDays = { ...routines[routineIndex].days };
      newDays[day] = { ...newDays[day], people: emoji };
      handleRoutineChange(routineIndex, 'days', newDays);
    }
    setShowEmojiSelector(false);
    setSelectedCell(null);
  };

  const addRoutine = () => {
    const newRoutine: RoutineEntry = {
      routine: "",
      idealTime: "",
      days: daysOfWeek.reduce((acc, day) => ({ ...acc, [day]: { actualTime: "", people: "" } }), {})
    };
    setRoutines([...routines, newRoutine]);
  };

  const handleSave = () => {
    saveMutation.mutate({ weekOf, routines });
  };

  const handleMoodChange = (index: number, value: string) => {
    // Handle mood/energy rating change
    const numValue = parseInt(value);
    if (numValue >= -5 && numValue <= 5) {
      // Update mood data if needed
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header with Illustration */}
      <div className="text-center mb-8">
        <div className="flex justify-center items-center mb-6">
          <div className="w-64 h-48 bg-gradient-to-br from-yellow-100 to-pink-100 rounded-2xl shadow-lg flex items-center justify-center animate-float overflow-hidden">
            <img 
              src={childWithBuds} 
              alt="Peaceful child with nature elements" 
              className="w-full h-full object-cover rounded-2xl opacity-80"
            />
          </div>
        </div>
        <h2 className="text-4xl font-bold text-gray-800 mb-2">Social Rhythm Chart</h2>
        <p className="text-gray-600 text-lg">Track your daily routines and social interactions</p>
      </div>

      {/* Week Selector */}
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <label className="text-lg font-semibold text-gray-700">Week of:</label>
            <Input
              type="date"
              value={weekOf}
              onChange={(e) => setWeekOf(e.target.value)}
              className="w-auto"
            />
          </div>
        </CardContent>
      </Card>

      {/* Social Rhythm Chart */}
      <Card className="mb-8">
        <div className="rhythm-chart-container p-6 rounded-t-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-white/20 backdrop-blur-sm">
                  <th className="text-left p-4 font-semibold text-white min-w-[200px]">Routine</th>
                  <th className="text-center p-4 font-semibold text-white min-w-[100px]">Ideal Time</th>
                  {daysOfWeek.map(day => (
                    <th key={day} className="text-center p-4 font-semibold text-white min-w-[120px]" colSpan={2}>
                      {day.charAt(0).toUpperCase() + day.slice(1)}
                    </th>
                  ))}
                </tr>
                <tr className="bg-white/10 backdrop-blur-sm">
                  <th className="p-2"></th>
                  <th className="p-2"></th>
                  {daysOfWeek.map(day => (
                    <React.Fragment key={day}>
                      <th className="text-center p-2 text-white text-xs">Actual Time</th>
                      <th className="text-center p-2 text-white text-xs">People</th>
                    </React.Fragment>
                  ))}
                </tr>
              </thead>
              <tbody className="bg-white/90 backdrop-blur-sm">
                {routines.map((routine, routineIndex) => (
                  <tr key={routineIndex} className="border-b border-gray-200">
                    <td className="p-4">
                      <Input
                        value={routine.routine}
                        onChange={(e) => handleRoutineChange(routineIndex, 'routine', e.target.value)}
                        placeholder="Add routine..."
                        className="border-0 bg-transparent text-gray-800 focus:ring-2 focus:ring-primary"
                      />
                    </td>
                    <td className="p-2 text-center">
                      <Input
                        type="time"
                        value={routine.idealTime}
                        onChange={(e) => handleRoutineChange(routineIndex, 'idealTime', e.target.value)}
                        className="border-0 bg-transparent text-center text-sm focus:ring-2 focus:ring-primary"
                      />
                    </td>
                    {daysOfWeek.map(day => (
                      <React.Fragment key={`${routineIndex}-${day}`}>
                        <td className="p-2 text-center">
                          <Input
                            type="time"
                            value={routine.days[day]?.actualTime || ""}
                            onChange={(e) => handleTimeChange(routineIndex, day, e.target.value)}
                            className="border-0 bg-transparent text-center text-sm focus:ring-2 focus:ring-primary"
                          />
                        </td>
                        <td className="p-2 text-center">
                          <button
                            onClick={() => handleEmojiClick(routineIndex, day)}
                            className="text-lg hover:scale-110 transition-transform w-full h-full min-h-[40px]"
                          >
                            {routine.days[day]?.people || "➕"}
                          </button>
                        </td>
                      </React.Fragment>
                    ))}
                  </tr>
                ))}
                
                {/* Mood/Energy Row */}
                <tr className="bg-gradient-to-r from-purple-50 to-pink-50">
                  <td className="p-4 font-medium text-gray-800">Mood/Energy (-5 to +5)</td>
                  <td className="p-2 text-center">
                    <span className="text-sm text-gray-500">N/A</span>
                  </td>
                  {daysOfWeek.map(day => (
                    <td key={`${day}-mood`} className="p-2 text-center" colSpan={2}>
                      <Input
                        type="number"
                        min="-5"
                        max="5"
                        placeholder="0"
                        onChange={(e) => handleMoodChange(0, e.target.value)}
                        className="w-16 border-0 bg-transparent text-center text-sm focus:ring-2 focus:ring-primary"
                      />
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </Card>

      {/* Add Routine Button */}
      <div className="text-center mb-6">
        <Button onClick={addRoutine} className="bg-primary hover:bg-purple-600">
          <Plus className="w-4 h-4 mr-2" />
          Add Routine
        </Button>
      </div>

      {/* Floating Save Button */}
      <div className="fixed bottom-6 right-6">
        <Button
          onClick={handleSave}
          disabled={saveMutation.isPending}
          className="bg-gradient-to-r from-primary to-secondary hover:from-purple-600 hover:to-blue-600 p-4 rounded-full shadow-lg hover:shadow-xl animate-pulse-slow"
        >
          <Save className="w-5 h-5" />
        </Button>
      </div>

      <EmojiSelector
        isOpen={showEmojiSelector}
        onClose={() => setShowEmojiSelector(false)}
        onSelect={handleEmojiSelect}
      />
    </div>
  );
}
