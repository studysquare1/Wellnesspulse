import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Calendar, TrendingUp, Activity } from "lucide-react";

const MOOD_COLORS = {
  'mania': '#ef4444',
  'hypomania': '#f97316', 
  'euthymia': '#22c55e',
  'depression': '#3b82f6',
  'major-depression': '#8b5cf6'
};

export default function Analytics() {
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());
  const [selectedMonth, setSelectedMonth] = useState((new Date().getMonth() + 1).toString());
  const [viewType, setViewType] = useState<'weekly' | 'monthly'>('monthly');

  const currentDate = new Date();
  const startOfWeek = new Date(currentDate);
  startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);

  const { data: weeklyData } = useQuery({
    queryKey: [`/api/analytics/weekly/${startOfWeek.toISOString().split('T')[0]}/${endOfWeek.toISOString().split('T')[0]}`],
    enabled: viewType === 'weekly',
  });

  const { data: monthlyData } = useQuery({
    queryKey: [`/api/analytics/monthly/${selectedYear}/${selectedMonth}`],
    enabled: viewType === 'monthly',
  });

  const currentData = viewType === 'monthly' ? monthlyData : weeklyData;

  const moodData = currentData?.moodAnalytics ? 
    Object.entries(currentData.moodAnalytics).map(([mood, count]) => ({
      name: mood.charAt(0).toUpperCase() + mood.slice(1).replace('-', ' '),
      value: count as number,
      color: MOOD_COLORS[mood as keyof typeof MOOD_COLORS]
    })) : [];

  const timePeriodData = currentData?.timePeriodMoods ? 
    Object.entries(currentData.timePeriodMoods).map(([period, moods]) => {
      const moodEntries = Object.entries(moods as Record<string, number>);
      const dominantMood = moodEntries.reduce((a, b) => a[1] > b[1] ? a : b, ['', 0]);
      return {
        period,
        dominantMood: dominantMood[0],
        count: dominantMood[1],
        allMoods: moods
      };
    }) : [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold text-gray-800 mb-2">Analytics Dashboard</h2>
        <p className="text-gray-600 text-lg">Insights into your mood patterns and social rhythms</p>
      </div>

      {/* View Toggle and Date Selector */}
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex space-x-4">
              <Button
                onClick={() => setViewType('weekly')}
                variant={viewType === 'weekly' ? "default" : "outline"}
              >
                <Calendar className="w-4 h-4 mr-2" />
                Weekly View
              </Button>
              <Button
                onClick={() => setViewType('monthly')}
                variant={viewType === 'monthly' ? "default" : "outline"}
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Monthly View
              </Button>
            </div>
            
            {viewType === 'monthly' && (
              <div className="flex space-x-4">
                <div className="flex items-center space-x-2">
                  <label className="text-sm font-medium">Year:</label>
                  <Input
                    type="number"
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(e.target.value)}
                    className="w-20"
                    min="2020"
                    max="2030"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <label className="text-sm font-medium">Month:</label>
                  <Input
                    type="number"
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                    className="w-20"
                    min="1"
                    max="12"
                  />
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Analytics Data */}
      {currentData && (
        <div className="space-y-8">
          {/* Time Period Mood Analysis */}
          {timePeriodData.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="w-5 h-5" />
                  <span>Dominant Moods by Time Period</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {timePeriodData.map(({ period, dominantMood, count }) => (
                    <div key={period} className="text-center p-4 bg-gray-50 rounded-lg">
                      <div className="text-2xl mb-2">
                        {dominantMood === 'mania' && '🔥'}
                        {dominantMood === 'hypomania' && '⚡'}
                        {dominantMood === 'euthymia' && '😌'}
                        {dominantMood === 'depression' && '😔'}
                        {dominantMood === 'major-depression' && '😞'}
                      </div>
                      <h4 className="font-semibold text-sm">{period}</h4>
                      <p className="text-xs text-gray-600 capitalize">
                        {dominantMood.replace('-', ' ')}
                      </p>
                      <p className="text-xs text-gray-500">({count} entries)</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Overall Mood Distribution */}
            {moodData.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="w-5 h-5" />
                    <span>Mood Distribution</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={moodData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {moodData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}

            {/* Summary Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="w-5 h-5" />
                  <span>Summary Statistics</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Total Mood Entries:</span>
                    <span className="font-semibold">{currentData.totalMoodEntries || 0}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600">Total Rhythm Entries:</span>
                    <span className="font-semibold">{currentData.totalRhythmEntries || 0}</span>
                  </div>
                  {moodData.length > 0 && (
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Most Common Mood:</span>
                      <span className="font-semibold capitalize">
                        {moodData.reduce((prev, current) => (prev.value > current.value) ? prev : current).name}
                      </span>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* No Data Message */}
      {!currentData && (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <Activity className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No data available for the selected period.</p>
              <p className="text-sm text-gray-500 mt-2">Start tracking your mood and social rhythm to see analytics here.</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}