import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Save, Smile, PenTool } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import EmojiSelector from "@/components/emoji-selector";
import { apiRequest } from "@/lib/queryClient";
import { formatDate, getMoodFromY, getTimeFromX, getTimePeriods, type MoodPoint } from "@/lib/mood-utils";
import type { MoodEntry } from "@shared/schema";

export default function DailyMood() {
  const [selectedDate, setSelectedDate] = useState(formatDate(new Date()));
  const [moodPoints, setMoodPoints] = useState<MoodPoint[]>([]);
  const [selectedPoint, setSelectedPoint] = useState<number | null>(null);
  const [showEmojiSelector, setShowEmojiSelector] = useState(false);
  const [drawingMode, setDrawingMode] = useState(true); // Line drawing by default
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentStroke, setCurrentStroke] = useState<MoodPoint[]>([]);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: moodData } = useQuery<MoodEntry>({
    queryKey: [`/api/mood/${selectedDate}`],
    enabled: !!selectedDate,
  });

  const saveMutation = useMutation({
    mutationFn: async (data: { date: string; moodPoints: MoodPoint[] }) => {
      const response = await apiRequest("POST", "/api/mood", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/mood/${selectedDate}`] });
      toast({
        title: "Saved!",
        description: "Your mood chart has been saved.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save your mood chart.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (moodData?.moodPoints) {
      setMoodPoints(moodData.moodPoints);
    }
  }, [moodData]);

  const smoothLine = (points: MoodPoint[]): MoodPoint[] => {
    if (points.length < 3) return points;
    
    // Sort points by x coordinate
    const sortedPoints = [...points].sort((a, b) => a.x - b.x);
    
    // Simple line straightening - linear interpolation between first and last points
    const firstPoint = sortedPoints[0];
    const lastPoint = sortedPoints[sortedPoints.length - 1];
    
    const smoothedPoints: MoodPoint[] = [];
    const numPoints = Math.max(5, Math.floor((lastPoint.x - firstPoint.x) / 2)); // Adjust density
    
    for (let i = 0; i <= numPoints; i++) {
      const t = i / numPoints;
      const x = firstPoint.x + t * (lastPoint.x - firstPoint.x);
      const y = firstPoint.y + t * (lastPoint.y - firstPoint.y);
      
      const time = getTimeFromX(x);
      const mood = getMoodFromY(y);
      
      smoothedPoints.push({
        time,
        mood,
        emoji: "●",
        x,
        y,
      });
    }
    
    return smoothedPoints;
  };

  const handleChartClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (drawingMode) {
      const rect = e.currentTarget.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const xPercent = (x / rect.width) * 100;
      const yPercent = (y / rect.height) * 100;
      
      const time = getTimeFromX(xPercent);
      const mood = getMoodFromY(yPercent);
      
      const newPoint: MoodPoint = {
        time,
        mood,
        emoji: "●",
        x: xPercent,
        y: yPercent,
      };
      
      if (isDrawing) {
        setCurrentStroke([...currentStroke, newPoint]);
      } else {
        setMoodPoints([...moodPoints, newPoint]);
      }
    }
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (drawingMode) {
      setIsDrawing(true);
      setCurrentStroke([]);
      handleChartClick(e);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (drawingMode && isDrawing) {
      handleChartClick(e);
    }
  };

  const handleMouseUp = () => {
    if (isDrawing && currentStroke.length > 1) {
      // Smooth the current stroke and add to mood points
      const smoothedStroke = smoothLine(currentStroke);
      const newMoodPoints = [...moodPoints, ...smoothedStroke];
      setMoodPoints(newMoodPoints);
    }
    setIsDrawing(false);
    setCurrentStroke([]);
  };

  const handlePointClick = (index: number, e: React.MouseEvent) => {
    if (!drawingMode) {
      e.stopPropagation();
      setSelectedPoint(index);
      setShowEmojiSelector(true);
    }
  };

  const handleEmojiSelect = (emoji: string) => {
    if (selectedPoint !== null) {
      const newPoints = [...moodPoints];
      newPoints[selectedPoint] = { ...newPoints[selectedPoint], emoji };
      setMoodPoints(newPoints);
    }
    setShowEmojiSelector(false);
    setSelectedPoint(null);
  };

  const handleSave = () => {
    saveMutation.mutate({ date: selectedDate, moodPoints });
  };

  const handleClear = () => {
    setMoodPoints([]);
  };

  const timePeriods = getTimePeriods();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-4xl font-bold text-gray-800 mb-2">Daily Mood Chart</h2>
        <p className="text-gray-600 text-lg">Track your mood throughout the day</p>
      </div>

      {/* Date Selector */}
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-4">
            <label className="text-lg font-semibold text-gray-700">Date:</label>
            <Input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="w-auto"
            />
          </div>
        </CardContent>
      </Card>

      {/* Mode Toggle */}
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="flex justify-center space-x-4">
            <Button
              onClick={() => setDrawingMode(true)}
              variant={drawingMode ? "default" : "outline"}
              className="flex items-center space-x-2"
            >
              <PenTool className="w-4 h-4" />
              <span>Draw Line</span>
            </Button>
            <Button
              onClick={() => setDrawingMode(false)}
              variant={!drawingMode ? "default" : "outline"}
              className="flex items-center space-x-2"
            >
              <Smile className="w-4 h-4" />
              <span>Add Emojis</span>
            </Button>
            <Button
              onClick={handleClear}
              variant="outline"
              className="flex items-center space-x-2 text-red-600 hover:text-red-700"
            >
              <span>Clear Chart</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Mood Chart Container */}
      <Card className="mb-8">
        <div className="mood-chart-container p-6 rounded-t-2xl">
          <div className="flex">
            {/* Mood Scale */}
            <div className="w-40 mr-6">
              <div className="mood-scale h-96 w-full rounded-lg relative flex flex-col justify-between p-2">
                <div className="text-white font-bold text-sm p-2 bg-black/30 rounded text-center">Mania</div>
                <div className="text-white font-bold text-sm p-2 bg-black/30 rounded text-center">Hypomania</div>
                <div className="text-white font-bold text-sm p-2 bg-black/30 rounded text-center">Euthymia</div>
                <div className="text-white font-bold text-sm p-2 bg-black/30 rounded text-center">Subthreshold Depression</div>
                <div className="text-white font-bold text-sm p-2 bg-black/30 rounded text-center">Major Depression</div>
              </div>
            </div>

            {/* Chart Area */}
            <div className="flex-1">
              <div 
                className={`bg-white/90 backdrop-blur-sm rounded-lg p-6 h-96 relative overflow-hidden ${
                  drawingMode ? 'cursor-crosshair' : 'cursor-pointer'
                }`}
                onClick={handleChartClick}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
              >
                {/* Time Labels - Starting from 5 AM */}
                <div className="absolute bottom-0 left-0 right-0 flex justify-between text-sm text-gray-600 px-4 pointer-events-none">
                  <span>05:00</span>
                  <span>08:00</span>
                  <span>11:00</span>
                  <span>14:00</span>
                  <span>17:00</span>
                  <span>20:00</span>
                  <span>23:00</span>
                  <span>02:00</span>
                </div>

                {/* Mood Points */}
                <div className="absolute inset-0">
                  {moodPoints.map((point, index) => (
                    <button
                      key={index}
                      onClick={(e) => handlePointClick(index, e)}
                      className={`absolute text-lg hover:scale-110 transition-transform ${
                        drawingMode ? 'pointer-events-none' : ''
                      } ${drawingMode ? 'text-blue-600' : ''}`}
                      style={{ left: `${point.x}%`, top: `${point.y}%` }}
                    >
                      {point.emoji}
                    </button>
                  ))}
                </div>

                {/* Connect dots with lines for drawing mode */}
                {drawingMode && moodPoints.length > 1 && (
                  <svg className="absolute inset-0 pointer-events-none w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                    <path
                      d={`M ${moodPoints.map((point, index) => 
                        `${point.x} ${point.y}`
                      ).join(' L ')}`}
                      stroke="#2563eb"
                      strokeWidth="0.5"
                      fill="none"
                      vectorEffect="non-scaling-stroke"
                    />
                  </svg>
                )}

                {/* Grid Lines */}
                <div className="absolute inset-0 pointer-events-none">
                  <div className="h-full flex">
                    {Array.from({ length: 8 }, (_, i) => (
                      <div key={i} className="flex-1 border-r border-gray-200 last:border-r-0" />
                    ))}
                  </div>
                  <div className="w-full flex flex-col">
                    {Array.from({ length: 5 }, (_, i) => (
                      <div key={i} className="flex-1 border-b border-gray-200 last:border-b-0" />
                    ))}
                  </div>
                  {/* Euthymia baseline - more prominent */}
                  <div
                    className="absolute w-full border-t-2 border-blue-400 bg-blue-50"
                    style={{ top: '50%', height: '2px' }}
                  />
                  <div 
                    className="absolute text-xs font-medium text-blue-600 bg-blue-50 px-2 py-1 rounded"
                    style={{ top: '50%', left: '2px', transform: 'translateY(-50%)' }}
                  >
                    Euthymia Baseline
                  </div>
                </div>

                {/* Current stroke preview during drawing */}
                {isDrawing && currentStroke.length > 1 && (
                  <svg className="absolute inset-0 pointer-events-none w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                    <path
                      d={`M ${currentStroke.map((point, index) => 
                        `${point.x} ${point.y}`
                      ).join(' L ')}`}
                      stroke="#60a5fa"
                      strokeWidth="0.7"
                      fill="none"
                      vectorEffect="non-scaling-stroke"
                      strokeDasharray="2,2"
                    />
                  </svg>
                )}
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Time Period Selector */}
      <Card>
        <CardContent className="pt-6">
          <h3 className="text-xl font-bold text-gray-800 mb-4">Time Periods (3-hour intervals)</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {timePeriods.map((period, index) => (
              <div key={index} className={`text-center p-4 bg-gradient-to-r ${period.bgClass} rounded-lg`}>
                <div className="text-lg font-semibold text-gray-800">{period.label}</div>
                <div className="text-sm text-gray-600">{period.period}</div>
                <div className="text-2xl mt-2">{period.emoji}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Floating Save Button */}
      <div className="fixed bottom-6 right-6">
        <Button
          onClick={handleSave}
          disabled={saveMutation.isPending}
          className="bg-gradient-to-r from-primary to-secondary hover:from-purple-600 hover:to-blue-600 p-4 rounded-full shadow-lg hover:shadow-xl animate-pulse-slow"
        >
          <Save className="w-5 h-5" />
        </Button>
      </div>

      <EmojiSelector
        isOpen={showEmojiSelector}
        onClose={() => setShowEmojiSelector(false)}
        onSelect={handleEmojiSelect}
      />
    </div>
  );
}
