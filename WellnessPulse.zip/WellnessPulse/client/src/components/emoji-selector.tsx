import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface EmojiSelectorProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (emoji: string) => void;
}

const emotionEmojis = [
  "😊", "😃", "😌", "😔", "😞", "😢", "😰", "😡", "🤗", "🥰", "😴", "🤯"
];

const activityEmojis = [
  "👥", "🏠", "💪", "🎉", "📚", "🛁", "🧘", "🍵", "🌟", "✨", "🌙", "☀️"
];

const gifEmojis = {
  happy: "🎈",
  calm: "🧘‍♀️",
  energetic: "⚡"
};

export default function EmojiSelector({ isOpen, onClose, onSelect }: EmojiSelectorProps) {
  const handleEmojiSelect = (emoji: string) => {
    onSelect(emoji);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex justify-between items-center">
            Select Emoji
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="w-4 h-4" />
            </Button>
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <h4 className="text-sm font-semibold text-gray-600 mb-3">Emotions</h4>
            <div className="grid grid-cols-6 gap-3">
              {emotionEmojis.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => handleEmojiSelect(emoji)}
                  className="text-2xl hover:scale-110 transition-transform p-2 rounded hover:bg-gray-100"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-sm font-semibold text-gray-600 mb-3">Activities</h4>
            <div className="grid grid-cols-6 gap-3">
              {activityEmojis.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => handleEmojiSelect(emoji)}
                  className="text-2xl hover:scale-110 transition-transform p-2 rounded hover:bg-gray-100"
                >
                  {emoji}
                </button>
              ))}
            </div>
          </div>

          <div className="border-t pt-4">
            <h4 className="text-sm font-semibold text-gray-600 mb-3">Quick Moods</h4>
            <div className="grid grid-cols-3 gap-2">
              {Object.entries(gifEmojis).map(([mood, emoji]) => (
                <button
                  key={mood}
                  onClick={() => handleEmojiSelect(emoji)}
                  className="bg-gradient-to-r from-purple-100 to-pink-100 p-3 rounded-lg hover:scale-105 transition-transform text-center"
                >
                  <div className="text-lg mb-1">{emoji}</div>
                  <div className="text-xs text-gray-600 capitalize">{mood}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
