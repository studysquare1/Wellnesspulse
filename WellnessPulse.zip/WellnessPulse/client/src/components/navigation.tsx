import { Link, useLocation } from "wouter";
import { Heart, Calendar, TrendingUp } from "lucide-react";

export default function Navigation() {
  const [location] = useLocation();

  const isActive = (path: string) => {
    if (path === "/" && (location === "/" || location === "/social-rhythm")) return true;
    return location === path;
  };

  return (
    <nav className="bg-white/80 backdrop-blur-sm shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center">
              <Heart className="text-white w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold text-gray-800">Mental Health Tracker</h1>
          </div>
          
          <div className="flex space-x-4">
            <Link href="/social-rhythm">
              <button
                className={`px-4 py-2 rounded-full font-medium transition-all duration-300 ${
                  isActive("/social-rhythm") || isActive("/")
                    ? "bg-primary text-white shadow-md"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                <Calendar className="inline w-4 h-4 mr-2" />
                Social Rhythm
              </button>
            </Link>
            <Link href="/daily-mood">
              <button
                className={`px-4 py-2 rounded-full font-medium transition-all duration-300 ${
                  isActive("/daily-mood")
                    ? "bg-primary text-white shadow-md"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                <TrendingUp className="inline w-4 h-4 mr-2" />
                Daily Mood
              </button>
            </Link>
            <Link href="/analytics">
              <button
                className={`px-4 py-2 rounded-full font-medium transition-all duration-300 ${
                  isActive("/analytics")
                    ? "bg-primary text-white shadow-md"
                    : "text-gray-600 hover:bg-gray-100"
                }`}
              >
                <TrendingUp className="inline w-4 h-4 mr-2" />
                Analytics
              </button>
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
}
