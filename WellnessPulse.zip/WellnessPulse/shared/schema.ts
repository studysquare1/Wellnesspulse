import { pgTable, text, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const rhythmEntries = pgTable("rhythm_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  weekOf: text("week_of").notNull(),
  routines: jsonb("routines").$type<RoutineEntry[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const moodEntries = pgTable("mood_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  date: text("date").notNull(),
  moodPoints: jsonb("mood_points").$type<MoodPoint[]>().notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Type definitions
export interface RoutineEntry {
  routine: string;
  idealTime: string;
  days: {
    [key: string]: {
      actualTime: string;
      people: string; // emoji representation
    };
  };
}

export interface MoodPoint {
  time: string;
  mood: 'mania' | 'hypomania' | 'euthymia' | 'depression' | 'major-depression';
  emoji: string;
  x: number;
  y: number;
}

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertRhythmEntrySchema = createInsertSchema(rhythmEntries).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type RhythmEntry = typeof rhythmEntries.$inferSelect;
export type MoodEntry = typeof moodEntries.$inferSelect;
export type InsertRhythmEntry = z.infer<typeof insertRhythmEntrySchema>;
export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
