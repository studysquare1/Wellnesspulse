import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertRhythmEntrySchema, insertMoodEntrySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Rhythm Chart Routes
  app.get("/api/rhythm/:weekOf", async (req, res) => {
    try {
      const { weekOf } = req.params;
      const userId = 1; // For now, using default user
      
      const entry = await storage.getRhythmEntry(userId, weekOf);
      
      if (!entry) {
        return res.json({ routines: [] });
      }
      
      res.json(entry);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch rhythm entry" });
    }
  });

  app.post("/api/rhythm", async (req, res) => {
    try {
      const data = insertRhythmEntrySchema.parse({
        ...req.body,
        userId: 1, // For now, using default user
      });
      
      const existingEntry = await storage.getRhythmEntry(data.userId!, data.weekOf);
      
      if (existingEntry) {
        const updatedEntry = await storage.updateRhythmEntry(existingEntry.id, data);
        res.json(updatedEntry);
      } else {
        const newEntry = await storage.createRhythmEntry(data);
        res.json(newEntry);
      }
    } catch (error) {
      res.status(400).json({ message: "Invalid rhythm entry data" });
    }
  });

  // Mood Chart Routes
  app.get("/api/mood/:date", async (req, res) => {
    try {
      const { date } = req.params;
      const userId = 1; // For now, using default user
      
      const entry = await storage.getMoodEntry(userId, date);
      
      if (!entry) {
        return res.json({ moodPoints: [] });
      }
      
      res.json(entry);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch mood entry" });
    }
  });

  app.post("/api/mood", async (req, res) => {
    try {
      const { date, moodPoints } = req.body;
      const userId = 1; // For now, using default user
      
      const existingEntry = await storage.getMoodEntry(userId, date);
      
      if (existingEntry) {
        const updatedEntry = await storage.updateMoodEntry(existingEntry.id, { moodPoints });
        res.json(updatedEntry);
      } else {
        const newEntry = await storage.createMoodEntry({ userId, date, moodPoints });
        res.json(newEntry);
      }
    } catch (error) {
      console.error("Mood entry error:", error);
      res.status(500).json({ message: "Failed to save mood entry", error: String(error) });
    }
  });

  // Analytics Routes
  app.get("/api/analytics/weekly/:startDate/:endDate", async (req, res) => {
    try {
      const { startDate, endDate } = req.params;
      const userId = 1; // For now, using default user
      
      const rhythmEntries = await storage.getRhythmEntriesForPeriod(userId, startDate, endDate);
      const moodEntries = await storage.getMoodEntriesForPeriod(userId, startDate, endDate);
      
      // Calculate mood analytics
      const moodAnalytics = moodEntries.reduce((acc, entry) => {
        entry.moodPoints.forEach(point => {
          acc[point.mood] = (acc[point.mood] || 0) + 1;
        });
        return acc;
      }, {} as Record<string, number>);
      
      // Calculate time-period mood analytics
      const timePeriodMoods = moodEntries.reduce((acc, entry) => {
        entry.moodPoints.forEach(point => {
          const hour = parseInt(point.time.split(':')[0]);
          let period = '';
          if (hour >= 5 && hour < 8) period = 'Early Morning';
          else if (hour >= 8 && hour < 11) period = 'Morning';
          else if (hour >= 11 && hour < 14) period = 'Late Morning';
          else if (hour >= 14 && hour < 17) period = 'Afternoon';
          else if (hour >= 17 && hour < 20) period = 'Evening';
          else if (hour >= 20 && hour < 23) period = 'Dusk';
          else if (hour >= 23 || hour < 2) period = 'Night';
          else period = 'Deep Night';
          
          if (!acc[period]) acc[period] = {};
          acc[period][point.mood] = (acc[period][point.mood] || 0) + 1;
        });
        return acc;
      }, {} as Record<string, Record<string, number>>);
      
      // Calculate rhythm consistency
      const rhythmAnalytics = rhythmEntries.map(entry => ({
        weekOf: entry.weekOf,
        routineCount: entry.routines.length,
        completedDays: entry.routines.reduce((count, routine) => {
          return count + Object.keys(routine.days).filter(day => routine.days[day].actualTime).length;
        }, 0)
      }));
      
      res.json({
        period: { startDate, endDate },
        moodAnalytics,
        timePeriodMoods,
        rhythmAnalytics,
        totalMoodEntries: moodEntries.length,
        totalRhythmEntries: rhythmEntries.length
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch analytics data" });
    }
  });

  app.get("/api/analytics/monthly/:year/:month", async (req, res) => {
    try {
      const { year, month } = req.params;
      const userId = 1; // For now, using default user
      
      const startDate = `${year}-${month.padStart(2, '0')}-01`;
      const endDate = new Date(parseInt(year), parseInt(month), 0).toISOString().split('T')[0];
      
      const rhythmEntries = await storage.getRhythmEntriesForPeriod(userId, startDate, endDate);
      const moodEntries = await storage.getMoodEntriesForPeriod(userId, startDate, endDate);
      
      // Calculate dominant mood for the month
      const moodCounts = moodEntries.reduce((acc, entry) => {
        entry.moodPoints.forEach(point => {
          acc[point.mood] = (acc[point.mood] || 0) + 1;
        });
        return acc;
      }, {} as Record<string, number>);
      
      const dominantMood = Object.entries(moodCounts).reduce((a, b) => 
        moodCounts[a[0]] > moodCounts[b[0]] ? a : b, ['euthymia', 0])[0];
      
      res.json({
        period: { year, month, startDate, endDate },
        dominantMood,
        moodDistribution: moodCounts,
        totalEntries: moodEntries.length,
        averageRhythmConsistency: rhythmEntries.length > 0 ? 
          rhythmEntries.reduce((sum, entry) => sum + entry.routines.length, 0) / rhythmEntries.length : 0
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch monthly analytics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
