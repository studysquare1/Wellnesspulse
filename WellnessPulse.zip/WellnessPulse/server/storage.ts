import { users, rhythmEntries, moodEntries, type User, type InsertUser, type RhythmEntry, type MoodEntry, type InsertRhythmEntry, type InsertMoodEntry } from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, desc } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getRhythmEntry(userId: number, weekOf: string): Promise<RhythmEntry | undefined>;
  createRhythmEntry(entry: InsertRhythmEntry): Promise<RhythmEntry>;
  updateRhythmEntry(id: number, entry: Partial<InsertRhythmEntry>): Promise<RhythmEntry | undefined>;
  
  getMoodEntry(userId: number, date: string): Promise<MoodEntry | undefined>;
  createMoodEntry(entry: InsertMoodEntry): Promise<MoodEntry>;
  updateMoodEntry(id: number, entry: Partial<InsertMoodEntry>): Promise<MoodEntry | undefined>;
  
  getRhythmEntriesForPeriod(userId: number, startDate: string, endDate: string): Promise<RhythmEntry[]>;
  getMoodEntriesForPeriod(userId: number, startDate: string, endDate: string): Promise<MoodEntry[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getRhythmEntry(userId: number, weekOf: string): Promise<RhythmEntry | undefined> {
    const [entry] = await db
      .select()
      .from(rhythmEntries)
      .where(and(eq(rhythmEntries.userId, userId), eq(rhythmEntries.weekOf, weekOf)));
    return entry || undefined;
  }

  async createRhythmEntry(insertEntry: InsertRhythmEntry): Promise<RhythmEntry> {
    const [entry] = await db
      .insert(rhythmEntries)
      .values(insertEntry as any)
      .returning();
    return entry;
  }

  async updateRhythmEntry(id: number, updateData: Partial<InsertRhythmEntry>): Promise<RhythmEntry | undefined> {
    const [entry] = await db
      .update(rhythmEntries)
      .set(updateData as any)
      .where(eq(rhythmEntries.id, id))
      .returning();
    return entry || undefined;
  }

  async getMoodEntry(userId: number, date: string): Promise<MoodEntry | undefined> {
    const [entry] = await db
      .select()
      .from(moodEntries)
      .where(and(eq(moodEntries.userId, userId), eq(moodEntries.date, date)));
    return entry || undefined;
  }

  async createMoodEntry(insertEntry: InsertMoodEntry): Promise<MoodEntry> {
    const [entry] = await db
      .insert(moodEntries)
      .values(insertEntry as any)
      .returning();
    return entry;
  }

  async updateMoodEntry(id: number, updateData: Partial<InsertMoodEntry>): Promise<MoodEntry | undefined> {
    const [entry] = await db
      .update(moodEntries)
      .set(updateData as any)
      .where(eq(moodEntries.id, id))
      .returning();
    return entry || undefined;
  }

  async getRhythmEntriesForPeriod(userId: number, startDate: string, endDate: string): Promise<RhythmEntry[]> {
    return await db
      .select()
      .from(rhythmEntries)
      .where(and(
        eq(rhythmEntries.userId, userId),
        gte(rhythmEntries.weekOf, startDate),
        lte(rhythmEntries.weekOf, endDate)
      ))
      .orderBy(desc(rhythmEntries.weekOf));
  }

  async getMoodEntriesForPeriod(userId: number, startDate: string, endDate: string): Promise<MoodEntry[]> {
    return await db
      .select()
      .from(moodEntries)
      .where(and(
        eq(moodEntries.userId, userId),
        gte(moodEntries.date, startDate),
        lte(moodEntries.date, endDate)
      ))
      .orderBy(desc(moodEntries.date));
  }
}

export const storage = new DatabaseStorage();
